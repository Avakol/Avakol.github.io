from modules.base_module import Module
import redis

r = redis.Redis(decode_responses=True)

# cls - одежда
# frn - мебель
# gm - игровое
# res - ресурсы

promocode = "ava-bang" # Промокод
r.sadd(f"offers:promocodes", promocode) # Добавить промокод в базу данных
r.set(f"offers:promocodes:{promocode}:promocode_title", "Награда") # Название окошечка
r.set(f"offers:promocodes:{promocode}:promocode_message", "Хах, ты опять повёлся на мои уловки!") # Сообщение при активации
r.set(f"offers:promocodes:{promocode}:promocode_item", "res:gld:100")  # Награда за промокод
print("Success")            

class_name = "Vip"

class Vip(Module):

    prefix = 'pc'
    def __init__(self, server):
        self.server = server
        self.commands = {'ac': self.pcac}

    async def pcac(self, msg, client): 
        return await client.send({'broadcast': False, 'text': f'Данного промокода\nне существует\nследи за новостями.\nСервера'}, type_=36)