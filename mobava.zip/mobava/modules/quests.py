import random, time
from location import Location
from modules.base_module import Module

class_name = "Quests"

class Quests(Module):
    prefix = 'q'
    def __init__(self, server):
        self.server = server
        self.commands = {'get': self.get_quests}

    async def get_quests(self, msg, client):
        qsts = []
        plqst = await self.sv.r.smembers(f"mb:qsts:{client.uid}")
        for qst in quests:
            if qst not in plqst:
                 if len(qsts) < 1:
                     if not await self.sv.r.get(f"mb:qsts:{client.uid}:{qst}:p"):
                         await self.sv.r.set(f"mb:qsts:{client.uid}:{qst}:p", 0)
                         pgs = 0
                     else: pgs - int(await self.sv.r.get(f"mb:qsts:{client.uid}:{qst}:p"))
                     quests[qst]['pr'] = pgs
                     qsts.append({'dur': 0, 'time': int(time.time()),
                                  'qid': qst, 'ts': [quests[qst]]})
                     await self.sv.r.set(f"mb:qsts:{client.uid}", qst)
        return await  client.send({'data': {'qc': {'q': qsts}},  'command': 'q.get'})       
                                  

