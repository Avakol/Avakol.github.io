from modules.base_module import Module

class_name = "Vip"

class Vip(Module):

    prefix = 'vp'
    def __init__(self, server):
        self.server = server
        self.commands = {'buy': self.vip}

    async def vip(self, msg, client):
        return await client.send({'broadcast': False, 'text': f'Купить премиум.\nmobile.ava-bang.xyz'}, type_=36)