import configparser
import aioredis
from aiogram import Bot, Dispatcher, executor, types
config = configparser.ConfigParser()
config.read('bot.ini')
TOKEN = config["bot"]["tg_token"]

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def on_startup(dispatcher, url=None, cert=None):
    global redis
    redis = await aioredis.create_redis_pool("redis://localhost",
                                         encoding="utf-8")


@dp.message_handler(commands=["start", "help"])
async def send_welcome(message: types.Message):
    await message.reply("Привет!\nЯ бот помощник для @avalandmobile!\n"
                        "Установить сервер - /link\nКупить премиум - /premium\nСоздатель сервера и бота - /creator\n"
                        f"\nПриятной игры на сервере!")

@dp.message_handler(commands=["premium"])
async def buy_premium(message: types.Message):
    await message.reply("Премиум можно купить у него:\n@gromov_cheat")

@dp.message_handler(commands=["creator"])
async def creator(message: types.Message):
    await message.reply("По вопросам сервера или бота сюда:@gromov_cheat")

@dp.message_handler(commands=["link"])
async def link_server(message: types.Message):
    await message.reply("Переходник на установку сервера:\nhttps://t.me/avangard_mobile/38")        

if __name__ == '__main__':
    executor.start_polling(dp, on_startup=on_startup, skip_updates=True)